package fr.isen.java2.db.daos;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import fr.isen.java2.db.entities.Genre;

public class GenreDao {

	public List<Genre> listGenres() {
	    List<Genre> genres = new ArrayList<>();
	    try (Connection connection = DataSourceFactory.getDataSource().getConnection();
	         PreparedStatement stmt = connection.prepareStatement("SELECT * FROM genre");
	         ResultSet resultSet = stmt.executeQuery()) {
	        while (resultSet.next()) {
	            int id = resultSet.getInt("idgenre");
	            String name = resultSet.getString("name");
	            Genre genre = new Genre(id, name);
	            genres.add(genre);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return genres;
	}
	public Genre getGenre(String name) {
	    Genre genre = null;
	    try (Connection connection = DataSourceFactory.getDataSource().getConnection();
	         PreparedStatement stmt = connection.prepareStatement("SELECT * FROM genre WHERE name = ?")) {
	        stmt.setString(1, name);
	        try (ResultSet resultSet = stmt.executeQuery()) {
	            if (resultSet.next()) {
	                int id = resultSet.getInt("idgenre");
	                String genreName = resultSet.getString("name");
	                genre = new Genre(id, genreName);
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return genre;}
	
	
	public void addGenre(String name) {
	    try (Connection connection = DataSourceFactory.getDataSource().getConnection();
	         PreparedStatement stmt = connection.prepareStatement("INSERT INTO genre(name) VALUES(?)")) {
	        stmt.setString(1, name);
	        stmt.executeUpdate();
	    } catch (SQLException e) {
	        e.printStackTrace();
	   }
	}
	}
